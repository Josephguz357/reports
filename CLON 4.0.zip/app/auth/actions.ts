"use server"

import { revalidatePath } from "next/cache"
import type { NeonQueryFunction } from "@neondatabase/serverless"
import { auth, clerkClient } from "@clerk/nextjs/server" // Import Clerk's server-side helpers

let _sql: NeonQueryFunction | null = null
async function getSql(): Promise<NeonQueryFunction | null> {
  if (typeof window !== "undefined") return null
  if (_sql) return _sql
  const { neon } = await import("@neondatabase/serverless")
  const connectionString = process.env.POSTGRES_URL ?? ""
  if (!connectionString) return null
  const g = globalThis as Record<string, any>
  _sql = g.__kaika_neon ??= neon(connectionString)
  return _sql
}

// signIn and signOut are now handled by Clerk's components/middleware
// We'll keep a dummy signIn for local preview if needed, but it won't be used in production with Clerk.
export async function signIn(formData: FormData) {
  // This function is largely deprecated with Clerk's SignIn component
  console.warn("signIn action is deprecated with Clerk. Use Clerk's <SignIn /> component.")
  return { success: false, message: "Use el componente de inicio de sesión de Clerk." }
}

export async function signOut() {
  // This function is largely deprecated with Clerk's SignOutButton component
  console.warn("signOut action is deprecated with Clerk. Use Clerk's <SignOutButton /> component.")
  return { success: false, message: "Use el componente de cierre de sesión de Clerk." }
}

export async function getUserSession() {
  const { userId } = auth() // Get Clerk's userId from the session

  if (!userId) {
    return null
  }

  // Fetch Clerk user details
  let clerkUser = null
  try {
    clerkUser = await clerkClient.users.getUser(userId)
  } catch (clerkError) {
    console.error("Error fetching Clerk user:", clerkError)
    return { clerkUser: null, profile: null, error: "Error al obtener datos de usuario de Clerk." }
  }

  // Fetch profile from the database using the Neon client
  let profile = null
  const sql = await getSql()
  if (sql) {
    try {
      const profilesResult = await sql`
        SELECT role, first_login
        FROM public.profiles
        WHERE id = ${userId}
      `
      if (profilesResult.length > 0) {
        profile = profilesResult[0]
      } else {
        // If profile doesn't exist in Neon, create it (first login scenario)
        await sql`
          INSERT INTO public.profiles (id, role, first_login)
          VALUES (${userId}, 'technician', TRUE)
        `
        profile = { role: "technician", first_login: true }
      }
    } catch (profileError) {
      console.error("Error fetching/creating profile from Neon:", profileError)
      return { clerkUser, profile: null, error: "Error al obtener/crear perfil de usuario." }
    }
  } else {
    console.warn("In-memory mode: Cannot fetch user profile from Neon. Requires DATABASE_URL.")
    profile = { role: "technician", first_login: false } // Default for preview
  }

  if (!profile) {
    console.error("Profile not found for user:", userId)
    return { clerkUser, profile: null, error: "Perfil de usuario no encontrado." }
  }

  return { clerkUser, profile }
}

export async function updateFirstLoginStatus(userId: string, status: boolean) {
  const sql = await getSql()
  if (!sql) {
    return {
      success: false,
      message: "No hay conexión a la base de datos para actualizar el estado de primer inicio de sesión.",
    }
  }
  try {
    await sql`
      UPDATE public.profiles
      SET first_login = ${status}, updated_at = NOW()
      WHERE id = ${userId}
    `
    revalidatePath("/", "layout")
    return { success: true, message: "Estado de primer inicio de sesión actualizado correctamente." }
  } catch (error) {
    console.error("Error updating first_login status with Neon:", error)
    return { success: false, message: `Error al actualizar el estado de primer inicio de sesión: ${error}` }
  }
}

// Admin-only actions for user management
export async function adminCreateUser(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const role = formData.get("role") as string // Desired role

  try {
    // Create user in Clerk
    const clerkUser = await clerkClient.users.createUser({
      emailAddress: email,
      password: password,
      skipPasswordChecks: true, // Clerk handles password strength
      // You can add publicMetadata here if you want to store role directly in Clerk
      // publicMetadata: { role: role }
    })

    const sql = await getSql()
    if (sql) {
      // Create or update profile in Neon with Clerk's user ID
      await sql`
        INSERT INTO public.profiles (id, role, first_login)
        VALUES (${clerkUser.id}, ${role}, TRUE)
        ON CONFLICT (id) DO UPDATE SET
          role = EXCLUDED.role,
          first_login = EXCLUDED.first_login,
          updated_at = NOW()
      `
    } else {
      console.warn("In-memory mode: Cannot create profile in Neon for new user. Requires DATABASE_URL.")
    }

    revalidatePath("/admin/users")
    return { success: true, message: `Usuario ${email} creado correctamente con rol ${role}.` }
  } catch (error: any) {
    console.error("Admin create user error:", error.errors ? error.errors[0].longMessage : error.message)
    return { success: false, message: error.errors ? error.errors[0].longMessage : "Error al crear usuario." }
  }
}

export async function adminDeleteUser(userId: string) {
  try {
    // Delete user in Clerk
    await clerkClient.users.deleteUser(userId)

    // The profile in Neon will need to be deleted manually or via a webhook from Clerk
    // For simplicity, we'll delete it here directly after Clerk deletion.
    const sql = await getSql()
    if (sql) {
      await sql`
        DELETE FROM public.profiles
        WHERE id = ${userId}
      `
    } else {
      console.warn("In-memory mode: Cannot delete profile in Neon. Requires DATABASE_URL.")
    }

    revalidatePath("/admin/users")
    return { success: true, message: "Usuario eliminado correctamente." }
  } catch (error: any) {
    console.error("Admin delete user error:", error.errors ? error.errors[0].longMessage : error.message)
    return { success: false, message: error.errors ? error.errors[0].longMessage : "Error al eliminar usuario." }
  }
}

export async function adminUpdateUserRole(userId: string, newRole: string) {
  const sql = await getSql()
  if (!sql) {
    return { success: false, message: "No hay conexión a la base de datos para actualizar el rol." }
  }
  try {
    await sql`
      UPDATE public.profiles
      SET role = ${newRole}, updated_at = NOW()
      WHERE id = ${userId}
    `
    revalidatePath("/admin/users")
    return { success: true, message: `Rol de usuario actualizado a ${newRole}.` }
  } catch (profileError) {
    console.error("Admin update user role error with Neon:", profileError)
    return { success: false, message: `Error al actualizar el rol de usuario: ${profileError}` }
  }
}

export async function adminGetAllUsers() {
  // Fetch users from Clerk
  let clerkUsers = []
  try {
    const clerkUsersResponse = await clerkClient.users.getUserList({ limit: 100 }) // Adjust limit as needed
    clerkUsers = clerkUsersResponse.data
  } catch (clerkError) {
    console.error("Error listing Clerk users:", clerkError)
    return { success: false, message: "Error al cargar usuarios de Clerk.", users: [] }
  }

  // Fetch profiles from Neon
  let profiles: { id: string; role: string; first_login: boolean }[] = []
  const sql = await getSql()
  if (sql) {
    const userIds = clerkUsers.map((user) => user.id)
    if (userIds.length > 0) {
      try {
        profiles = await sql`
          SELECT id, role, first_login
          FROM public.profiles
          WHERE id IN (${sql(userIds)})
        `
      } catch (profileError) {
        console.error("Error fetching user profiles from Neon:", profileError)
        return { success: false, message: `Error al cargar perfiles de usuario: ${profileError}`, users: [] }
      }
    }
  } else {
    console.warn("In-memory mode: Cannot fetch user profiles from Neon. Requires DATABASE_URL.")
  }

  // Combine Clerk user data with Neon profile data
  const usersWithProfiles = clerkUsers.map((user) => {
    const profile = profiles?.find((p) => p.id === user.id)
    return {
      id: user.id,
      email: user.emailAddresses[0]?.emailAddress || "N/A", // Get primary email
      created_at: user.createdAt ? new Date(user.createdAt).toISOString() : "N/A",
      last_sign_in_at: user.lastSignInAt ? new Date(user.lastSignInAt).toISOString() : null,
      role: profile?.role || "unknown", // Default to 'unknown' if profile not found
      first_login: profile?.first_login || false,
    }
  })

  return { success: true, users: usersWithProfiles }
}
