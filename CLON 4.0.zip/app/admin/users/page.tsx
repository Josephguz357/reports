"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowLeft, PlusCircle, Trash2 } from "lucide-react"
import { toast } from "sonner"
import { adminCreateUser, adminDeleteUser, adminUpdateUserRole, adminGetAllUsers } from "@/app/auth/actions"
import { useRouter } from "next/navigation"

interface User {
  id: string
  email: string
  role: string
  first_login: boolean
  created_at: string
  last_sign_in_at: string | null
}

export default function UserManagementPage() {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [newUserEmail, setNewUserEmail] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [newUserRole, setNewUserRole] = useState("technician")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    setLoading(true)
    const result = await adminGetAllUsers()
    if (result.success) {
      setUsers(result.users)
    } else {
      toast.error(result.message || "Error al cargar usuarios.")
    }
    setLoading(false)
  }

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newUserEmail || !newPassword || !newUserRole) {
      toast.error("Todos los campos son obligatorios.")
      return
    }
    // Clerk handles password strength, but a basic check is good for UX
    if (newPassword.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres.")
      return
    }

    const formData = new FormData()
    formData.append("email", newUserEmail)
    formData.append("password", newPassword)
    formData.append("role", newUserRole)

    const result = await adminCreateUser(formData)
    if (result.success) {
      toast.success(result.message)
      setNewUserEmail("")
      setNewPassword("")
      setNewUserRole("technician")
      fetchUsers() // Refresh list
    } else {
      toast.error(result.message || "Error al crear usuario.")
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!confirm("¿Está seguro que desea eliminar este usuario?")) {
      return
    }
    const result = await adminDeleteUser(userId)
    if (result.success) {
      toast.success(result.message)
      fetchUsers() // Refresh list
    } else {
      toast.error(result.message || "Error al eliminar usuario.")
    }
  }

  const handleUpdateUserRole = async (userId: string, newRole: string) => {
    const result = await adminUpdateUserRole(userId, newRole)
    if (result.success) {
      toast.success(result.message)
      fetchUsers() // Refresh list
    } else {
      toast.error(result.message || "Error al actualizar rol.")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 flex items-center justify-center p-6">
        <p className="text-white text-lg">Cargando usuarios...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Button
            variant="ghost"
            onClick={() => router.push("/dashboard")}
            className="text-white hover:bg-blue-700 mb-2"
          >
            <ArrowLeft className="h-4 w-4 mr-2" /> Volver al Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-white">Gestión de Usuarios</h1>
          <div></div> {/* Placeholder for alignment */}
        </div>

        <Card className="bg-white/95 backdrop-blur-sm shadow-xl mb-6">
          <CardHeader>
            <CardTitle className="text-black">Crear Nuevo Usuario</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateUser} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              <div>
                <Label htmlFor="newUserEmail" className="text-black">
                  Email
                </Label>
                <Input
                  id="newUserEmail"
                  type="email"
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  placeholder="ejemplo@kaika.com"
                  required
                  className="text-black"
                />
              </div>
              <div>
                <Label htmlFor="newPassword" className="text-black">
                  Contraseña Inicial
                </Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="text-black"
                  minLength={6}
                />
              </div>
              <div>
                <Label htmlFor="newUserRole" className="text-black">
                  Rol
                </Label>
                <Select value={newUserRole} onValueChange={setNewUserRole}>
                  <SelectTrigger className="text-black">
                    <SelectValue placeholder="Seleccionar Rol" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technician">Técnico</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-3 flex justify-end">
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  <PlusCircle className="h-4 w-4 mr-2" /> Crear Usuario
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card className="bg-white/95 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-black">Usuarios Existentes</CardTitle>
          </CardHeader>
          <CardContent>
            {users.length === 0 ? (
              <p className="text-gray-600 text-center">No hay usuarios registrados.</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-100">
                      <TableHead className="text-black">Email</TableHead>
                      <TableHead className="text-black">Rol</TableHead>
                      <TableHead className="text-black">Primer Inicio</TableHead>
                      <TableHead className="text-black">Creado</TableHead>
                      <TableHead className="text-black">Último Inicio</TableHead>
                      <TableHead className="text-black">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="text-black">{user.email}</TableCell>
                        <TableCell className="text-black">
                          <Select
                            value={user.role}
                            onValueChange={(newRole) => handleUpdateUserRole(user.id, newRole)}
                            // Disable editing for the initial admin user (if you want to keep it fixed)
                            // You'll need to get the Clerk ID for "JOSEPH357" after it's created.
                            // For now, no specific user is disabled by default.
                          >
                            <SelectTrigger className="w-[120px] h-8 text-xs text-black">
                              <SelectValue placeholder="Rol" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="technician">Técnico</SelectItem>
                              <SelectItem value="admin">Administrador</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="text-black">{user.first_login ? "Sí" : "No"}</TableCell>
                        <TableCell className="text-black">{new Date(user.created_at).toLocaleDateString()}</TableCell>
                        <TableCell className="text-black">
                          {user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleDateString() : "N/A"}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteUser(user.id)}
                            // Disable deleting for the initial admin user
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
