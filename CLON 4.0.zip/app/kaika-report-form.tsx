"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Save, Download, ArrowLeft, Trash2 } from "lucide-react"
import { toast } from "sonner"
import SignatureCapture from "../components/SignatureCapture"
import PdfReportContent from "../components/PdfReportContent"
import { usePDFExport } from "../hooks/usePDFExport"
import Image from "next/image"
import { saveReport } from "./actions" // Import the server action

interface KaikaReportFormProps {
  onBack: () => void
  initialData?: {
    id?: string // Report ID for existing reports
    formData: any
    technicianSignature: string
    clientSignature: string
    tecnicosAsignados: any[]
    actividadesSeleccionadas: string[]
    userId: string // Creator's user ID
    canEdit?: boolean // Indicates if the current user can edit this report
  }
  currentUserId: string
  isNewReport: boolean
  isAdmin: boolean
}

export default function KaikaReportForm({
  onBack,
  initialData,
  currentUserId,
  isNewReport,
  isAdmin,
}: KaikaReportFormProps) {
  const [reportId, setReportId] = useState<string | undefined>(initialData?.id)
  const [formData, setFormData] = useState({
    fechaInicio: "",
    horaInicio: "",
    fechaFin: "",
    horaFin: "",
    trabajos: "",
    compromisos: "",
    recomendaciones: "",
    recordarCompromiso: false,
    recordarRecomendaciones: false,
    tecnicoSeleccionado: "",
    mostrarGrupo: false,
    listaChequeo: "",
    personaEncuestada: "",
    tipoEvaluacion: "",
    mostrarTodo: false,
    seleccionarTodo: false,
    clienteNombre: "",
    clienteTelefono: "",
    clienteEmail: "",
    equipoNombre: "",
    equipoModelo: "",
    equipoMarca: "",
    equipoSerial: "",
    equipoNoInv: "",
    equipoUbicacion: "",
    ordenClienteNo: "",
    encargado: "",
    reportNumber: "",
    serviceTypes: {
      garantia: false,
      contrato: false,
      mantenimientoC: false,
      instalacion: false,
      desinstalacion: false,
      acompanamiento: false,
      diagnostico: false,
      capacitacion: false,
      calificacion: false,
    },
  })

  const [technicianSignature, setTechnicianSignature] = useState<string>("")
  const [clientSignature, setClientSignature] = useState<string>("")
  const { exportToPDF } = usePDFExport()

  const [tecnicos] = useState([
    { id: "1", nombre: "Daniel Sanchez", usuario: "Superadministrador" },
    { id: "2", nombre: "OLGA BARRERA", usuario: "admin" },
    { id: "5", nombre: "JAIDER ENRIQUE GUTIERREZ", usuario: "JAIDER GUTIERREZ" },
    { id: "7", nombre: "CARLOS ANDRES SIERRA", usuario: "CARLOS SIERRA" },
    { id: "8", nombre: "MICHELL NIÑO", usuario: "MICHELL NINO" },
    { id: "19", nombre: "JOSE ALBEIRO GUZMÁN", usuario: "JOSE GUZMAN" },
  ])

  const [tecnicosAsignados, setTecnicosAsignados] = useState([{ id: "19", nombre: "JOSE ALBEIRO GUZMÁN" }])

  const [actividades] = useState([
    {
      id: "1",
      nombre: "Verificación visual de estado físico. (Plafones y tornillos)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "2",
      nombre: "Limpieza interna del equipo (Remoción de polvo y suciedad).",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "3", nombre: "Mecánica", categoria: "CATEGORIA", seleccionada: false },
    { id: "4", nombre: "Limpiar la/s junta/s de la/s puerta/s", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "5",
      nombre: "Comprobar funcionamiento de las electroválvulas de entrada de agua. Desmontar y limpiar los filtros.",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "6",
      nombre: "Comprobar el funcionamiento de las boyas de nivel de los depósito/s de agua",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "7",
      nombre: "Comprobar el funcionamiento del termostato depósito de agua",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "8",
      nombre: "Cambiar el filtro de entrada aire estéril a la cámara (ANUALMENTE)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "9",
      nombre: "Comprobar funcionamiento de las válvulas de retención",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "10",
      nombre: "Verificar los purgadores termodinámicos| desmontar y limpiar (ANUALMENTE)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "11",
      nombre: "Verificar las electroválvulas del bloque neumático",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "12",
      nombre: "Verificar las electroválvulas del circuito hidráulico (series sin hidroneumáticas)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "13",
      nombre: "Comprobar funcionamiento de las válvulas hidroneumáticas",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "14",
      nombre: "Engrasar los regles de deslizamiento de la puerta",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "15",
      nombre: "Revisar y reparar posibles fugas de vapor| aire| agua| etc.",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "16",
      nombre: "Revisar y ajustar mariposas de acoples tipo clamp.",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "17",
      nombre: "Comprobar la dureza del agua entrada refrigeración ºF.............",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "18", nombre: "Generador de vapor", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "19",
      nombre: "Desmontar la tapa| limpiar las incrustaciones del sistema y cambio junta tapa (ANUALMENTE)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "20", nombre: "Drenaje completo.", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "21",
      nombre: "Verificar el funcionamiento del sistema de nivel| presostatos de control y manómetro.",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "22", nombre: "Compresor", categoria: "CATEGORIA", seleccionada: false },
    { id: "23", nombre: "Drenaje completo.", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "24",
      nombre: "Verificar el funcionamiento de: presostatos de control| alarma y manómetro.",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "25",
      nombre: "Comprobar el consumo Motor de la bomba de agua del generador",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "26", nombre: "Comprobar el consumo Elementos calefactores", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "27",
      nombre: "Comprobar el consumo Motor de la bomba de vacío",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "28", nombre: "Puertas y seguridades", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "29",
      nombre:
        "Verificar el funcionamiento de los seguros de bloqueo de la/s puerta/s y lubricar las partes mecánicas (No engrasar ni desmontar los pistones)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "30",
      nombre: 'Comprobar el funcionamiento correcto del paro de emergencia de la/s puerta/s "MANDO SETA".',
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "31",
      nombre: "Revisar el funcionamiento de los dispositivos de seguro de desplazamiento de la/s puerta/s",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    {
      id: "32",
      nombre:
        "Comprobar las válvulas de seguridad de cámara| recámara y generador| sometiéndolas a una prueba de presión| comprobando que disparan a la presión de timbre. (ANUALMENTE)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "33", nombre: "Ajustes y comprobaciones", categoria: "CATEGORIA", seleccionada: false },
    {
      id: "34",
      nombre:
        "Verificar el funcionamiento de los instrumentos de regulación y control y ajustar si fuera necesario: Temperatura cámara| Temperatura registro| Presión de cámara (ANUALMENTE)",
      categoria: "CATEGORIA",
      seleccionada: false,
    },
    { id: "35", nombre: "Pruebas de funcionamiento.", categoria: "CATEGORIA", seleccionada: false },
    { id: "36", nombre: "Realizar un test de vacío", categoria: "CATEGORIA", seleccionada: false },
    { id: "37", nombre: "Realizar un ciclo de Bowie & Dick", categoria: "CATEGORIA", seleccionada: false },
  ])

  const [actividadesSeleccionadas, setActividadesSeleccionadas] = useState<string[]>([])

  const [pdfExportOptions, setPdfExportOptions] = useState({
    includeClientEquipment: true,
    includeServiceType: true,
    includeBasicInfo: true,
    includeTechnicians: true,
    includeChecklistsActivities: true,
    includeEvaluation: true,
    includeTechnicianSignature: true,
    includeClientSignature: true,
    includeDateTimeWithClientSignature: true,
  })

  // Determine if the form is editable
  const isFormEditable = isNewReport || (initialData?.canEdit && !isNewReport)

  useEffect(() => {
    if (initialData) {
      setReportId(initialData.id)
      setFormData(initialData.formData)
      setTechnicianSignature(initialData.technicianSignature)
      setClientSignature(initialData.clientSignature)
      setTecnicosAsignados(initialData.tecnicosAsignados)
      setActividadesSeleccionadas(initialData.actividadesSeleccionadas)
    }
  }, [initialData])

  const handleInputChange = useCallback(
    (field: string, value: any) => {
      if (!isFormEditable) return // Prevent changes if not editable
      setFormData((prev) => ({ ...prev, [field]: value }))
    },
    [isFormEditable],
  )

  const handleServiceTypeChange = useCallback(
    (type: keyof typeof formData.serviceTypes, checked: boolean) => {
      if (!isFormEditable) return
      setFormData((prev) => ({
        ...prev,
        serviceTypes: { ...prev.serviceTypes, [type]: checked },
      }))
    },
    [isFormEditable],
  )

  const handleAgregarTecnico = useCallback(() => {
    if (!isFormEditable) return
    if (formData.tecnicoSeleccionado) {
      const tecnico = tecnicos.find((t) => t.id === formData.tecnicoSeleccionado)
      if (tecnico && !tecnicosAsignados.find((t) => t.id === tecnico.id)) {
        setTecnicosAsignados((prev) => [...prev, tecnico])
        setFormData((prev) => ({ ...prev, tecnicoSeleccionado: "" }))
        toast.success("Técnico agregado correctamente")
      }
    }
  }, [formData.tecnicoSeleccionado, tecnicosAsignados, tecnicos, isFormEditable])

  const handleEliminarTecnico = useCallback(
    (id: string) => {
      if (!isFormEditable) return
      setTecnicosAsignados((prev) => prev.filter((t) => t.id !== id))
      toast.success("Técnico eliminado")
    },
    [isFormEditable],
  )

  const handleActividadChange = useCallback(
    (actividadId: string, checked: boolean) => {
      if (!isFormEditable) return
      if (checked) {
        setActividadesSeleccionadas((prev) => (prev.includes(actividadId) ? prev : [...prev, actividadId]))
      } else {
        setActividadesSeleccionadas((prev) => prev.filter((id) => id !== actividadId))
      }
    },
    [isFormEditable],
  )

  const handleSeleccionarTodo = useCallback(() => {
    if (!isFormEditable) return
    if (formData.seleccionarTodo) {
      setActividadesSeleccionadas(Array.from(new Set(actividades.map((a) => a.id))))
    } else {
      setActividadesSeleccionadas([])
    }
  }, [formData.seleccionarTodo, actividades, isFormEditable])

  const handleSignatureSave = useCallback(
    (type: "technician" | "client", signatureData: string) => {
      if (!isFormEditable) return
      if (type === "technician") {
        setTechnicianSignature(signatureData)
      } else {
        setClientSignature(signatureData)
      }
      if (signatureData) {
        toast.success(`Firma de ${type === "technician" ? "técnico" : "cliente"} capturada correctamente`)
      } else {
        toast.info(`Firma de ${type === "technician" ? "técnico" : "cliente"} borrada`)
      }
    },
    [isFormEditable],
  )

  const handleExportPDF = async () => {
    const confirmExport = confirm("¿Está seguro que desea exportar el reporte a PDF?")
    if (!confirmExport) {
      toast.info("Exportación de PDF cancelada.")
      return
    }

    const sectionsToExport: string[] = ["pdf-full-report-content"]

    const actividadesList = actividades

    const success = await exportToPDF(sectionsToExport, `Reporte_Servicio_${formData.reportNumber || "Nuevo"}`, {
      ...formData,
      technicianSignature,
      clientSignature,
      tecnicosAsignados,
      actividadesSeleccionadas,
      actividadesList,
      pdfExportOptions,
    })

    if (success) {
      toast.success("PDF exportado correctamente")
    } else {
      toast.error("Error al exportar PDF")
    }
  }

  const handleSaveToDatabase = async () => {
    if (!isFormEditable) {
      toast.error("No tiene permiso para guardar cambios en este reporte.")
      return
    }

    const confirmSave = confirm("¿Está seguro que desea guardar este reporte en la base de datos?")
    if (!confirmSave) {
      toast.info("Guardado en base de datos cancelado.")
      return
    }

    if (!formData.reportNumber || !/^\d{8}$/.test(formData.reportNumber)) {
      toast.error("El número de reporte debe ser de 8 dígitos numéricos.")
      return
    }

    const result = await saveReport({
      formData,
      technicianSignature,
      clientSignature,
      tecnicosAsignados,
      actividadesSeleccionadas,
      reportId: isNewReport ? undefined : reportId, // Pass reportId only for updates
    })

    if (result.success) {
      toast.success(result.message)
      if (isNewReport && result.reportId) {
        // If a new report was created, update state to reflect it's now an existing report
        setReportId(result.reportId)
        // Optionally, redirect to a URL that reflects the new report ID if you have dynamic routes for reports
        // router.push(`/reports/${result.reportId}`);
      }
    } else {
      toast.error(result.message)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 p-6">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <Button variant="ghost" onClick={onBack} className="text-white hover:bg-blue-700 mb-2">
              <ArrowLeft className="h-4 w-4 mr-2" /> Volver al Dashboard
            </Button>
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold text-white">Reporte de Servicio</h1>
              <Input
                type="text"
                value={formData.reportNumber}
                onChange={(e) => {
                  const value = e.target.value
                  if (/^\d*$/.test(value) && value.length <= 8) {
                    handleInputChange("reportNumber", value)
                  }
                }}
                placeholder="No. Reporte (8 dígitos)"
                maxLength={8}
                required
                className="w-40 text-black"
                disabled={!isFormEditable && !isNewReport} // Disable editing report number for existing reports
              />
            </div>
            <p className="text-blue-100">
              {isNewReport ? "Creando Nuevo Reporte" : `Consultando Reporte ${formData.reportNumber}`}
              {!isFormEditable && !isNewReport && <span className="ml-2 text-yellow-200">(Solo lectura)</span>}
            </p>
          </div>
          <Button onClick={handleExportPDF} className="bg-white text-blue-600 hover:bg-blue-50">
            <Download className="h-4 w-4 mr-2" />
            Exportar PDF
          </Button>
        </div>
        {/* Report Content for PDF Export (Visible Form) */}
        <div id="report-content-visible">
          <Card className="bg-white/95 backdrop-blur-sm shadow-xl">
            <CardHeader className="bg-yellow-50 border border-yellow-200 rounded-t-lg p-4 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <Image
                      src="/images/kaika-logo.png"
                      alt="Kaika Logo"
                      width={368}
                      height={185}
                      className="object-contain"
                    />
                  </div>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                <div className="md:col-span-4 space-y-6">
                  <Card className="border border-gray-300">
                    <CardHeader>
                      <CardTitle className="text-black text-base">Detalles del Cliente y Equipo</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Label className="text-black text-xs w-20 shrink-0">CLIENTE</Label>
                        <Input
                          value={formData.clienteNombre}
                          onChange={(e) => handleInputChange("clienteNombre", e.target.value)}
                          className="h-7 text-xs flex-1 text-black"
                          disabled={!isFormEditable}
                        />
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1">
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">TELEFONO</Label>
                          <Input
                            value={formData.clienteTelefono}
                            onChange={(e) => handleInputChange("clienteTelefono", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">E-MAIL</Label>
                          <Input
                            type="email"
                            value={formData.clienteEmail}
                            onChange={(e) => handleInputChange("clienteEmail", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1">
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">EQUIPO</Label>
                          <Input
                            value={formData.equipoNombre}
                            onChange={(e) => handleInputChange("equipoNombre", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">MODELO</Label>
                          <Input
                            value={formData.equipoModelo}
                            onChange={(e) => handleInputChange("equipoModelo", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-4 gap-y-1">
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">MARCA</Label>
                          <Input
                            value={formData.equipoMarca}
                            onChange={(e) => handleInputChange("equipoMarca", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">SERIAL</Label>
                          <Input
                            value={formData.equipoSerial}
                            onChange={(e) => handleInputChange("equipoSerial", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">No. INV</Label>
                          <Input
                            value={formData.equipoNoInv}
                            onChange={(e) => handleInputChange("equipoNoInv", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1">
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">UBICACION</Label>
                          <Input
                            value={formData.equipoUbicacion}
                            onChange={(e) => handleInputChange("equipoUbicacion", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Label className="text-black text-xs w-20 shrink-0">ORDEN DE CLIENTE No.</Label>
                          <Input
                            value={formData.ordenClienteNo}
                            onChange={(e) => handleInputChange("ordenClienteNo", e.target.value)}
                            className="h-7 text-xs flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="text-black text-xs w-20 shrink-0">ENCARGADO</Label>
                        <Input
                          value={formData.encargado}
                          onChange={(e) => handleInputChange("encargado", e.target.value)}
                          placeholder="Nombre de la persona encuestada"
                          className="text-black"
                          disabled={!isFormEditable}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
                <div className="md:col-span-1 space-y-6">
                  <Card className="border border-gray-300">
                    <CardHeader>
                      <CardTitle className="text-black text-base">Tipo de Servicio</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="garantia"
                          checked={formData.serviceTypes.garantia}
                          onCheckedChange={(checked) => handleServiceTypeChange("garantia", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="garantia" className="text-[10px] text-black">
                          1. GARANTIA
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="contrato"
                          checked={formData.serviceTypes.contrato}
                          onCheckedChange={(checked) => handleServiceTypeChange("contrato", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="contrato" className="text-[10px] text-black">
                          2. CONTRATO
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="mantenimientoC"
                          checked={formData.serviceTypes.mantenimientoC}
                          onCheckedChange={(checked) => handleServiceTypeChange("mantenimientoC", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="mantenimientoC" className="text-[10px] text-black">
                          3. MANTENIMIENTO C
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="instalacion"
                          checked={formData.serviceTypes.instalacion}
                          onCheckedChange={(checked) => handleServiceTypeChange("instalacion", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="instalacion" className="text-[10px] text-black">
                          4. INSTALACION
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="desinstalacion"
                          checked={formData.serviceTypes.desinstalacion}
                          onCheckedChange={(checked) => handleServiceTypeChange("desinstalacion", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="desinstalacion" className="text-[10px] text-black">
                          5. DESINSTALACION
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="acompanamiento"
                          checked={formData.serviceTypes.acompanamiento}
                          onCheckedChange={(checked) => handleServiceTypeChange("acompanamiento", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="acompanamiento" className="text-[10px] text-black">
                          6. ACOMPAÑAMIENTO
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="diagnostico"
                          checked={formData.serviceTypes.diagnostico}
                          onCheckedChange={(checked) => handleServiceTypeChange("diagnostico", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="diagnostico" className="text-[10px] text-black">
                          7. DIAGNOSTICO
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="capacitacion"
                          checked={formData.serviceTypes.capacitacion}
                          onCheckedChange={(checked) => handleServiceTypeChange("capacitacion", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="capacitacion" className="text-[10px] text-black">
                          8. CAPACITACION
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="calificacion"
                          checked={formData.serviceTypes.calificacion}
                          onCheckedChange={(checked) => handleServiceTypeChange("calificacion", checked as boolean)}
                          disabled={!isFormEditable}
                        />
                        <Label htmlFor="calificacion" className="text-[10px] text-black">
                          9. CALIFICACION
                        </Label>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="space-y-6">
                <Card className="border border-gray-300">
                  <CardHeader>
                    <CardTitle className="text-black">Información Básica</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-black">Inicio</Label>
                        <div className="flex gap-2">
                          <Input
                            type="date"
                            value={formData.fechaInicio}
                            onChange={(e) => handleInputChange("fechaInicio", e.target.value)}
                            className="flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                          <Input
                            type="time"
                            value={formData.horaInicio}
                            onChange={(e) => handleInputChange("horaInicio", e.target.value)}
                            className="w-32 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                      </div>
                      <div>
                        <Label className="text-black">Fin</Label>
                        <div className="flex gap-2">
                          <Input
                            type="date"
                            value={formData.fechaFin}
                            onChange={(e) => handleInputChange("fechaFin", e.target.value)}
                            className="flex-1 text-black"
                            disabled={!isFormEditable}
                          />
                          <Input
                            type="time"
                            value={formData.horaFin}
                            onChange={(e) => handleInputChange("horaFin", e.target.value)}
                            className="w-32 text-black"
                            disabled={!isFormEditable}
                          />
                        </div>
                      </div>
                    </div>
                    <div>
                      <Label className="text-black">Trabajos</Label>
                      <Textarea
                        value={formData.trabajos}
                        onChange={(e) => handleInputChange("trabajos", e.target.value)}
                        placeholder="Describa los trabajos realizados..."
                        className="min-h-[100px] text-black"
                        disabled={!isFormEditable}
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-black">Compromisos</Label>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="recordarCompromiso"
                            checked={formData.recordarCompromiso}
                            onCheckedChange={(checked) => handleInputChange("recordarCompromiso", checked)}
                            disabled={!isFormEditable}
                          />
                          <Label htmlFor="recordarCompromiso" className="text-black">
                            Recordar
                          </Label>
                        </div>
                      </div>
                      <Textarea
                        value={formData.compromisos}
                        onChange={(e) => handleInputChange("compromisos", e.target.value)}
                        placeholder="Describa los compromisos..."
                        className="min-h-[100px] text-black"
                        disabled={!isFormEditable}
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-black">Recomendaciones</Label>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="recordarRecomendaciones"
                            checked={formData.recordarRecomendaciones}
                            onCheckedChange={(checked) => handleInputChange("recordarRecomendaciones", checked)}
                            disabled={!isFormEditable}
                          />
                          <Label htmlFor="recordarRecomendaciones" className="text-black">
                            Recordar
                          </Label>
                        </div>
                      </div>
                      <Textarea
                        value={formData.recomendaciones}
                        onChange={(e) => handleInputChange("recomendaciones", e.target.value)}
                        placeholder="Describa las recomendaciones..."
                        className="min-h-[100px] text-black"
                        disabled={!isFormEditable}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-300">
                  <CardHeader>
                    <CardTitle className="text-black">Listas de chequeo</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div>
                      <Label className="text-black">Listas de chequeo</Label>
                      <Select
                        value={formData.listaChequeo}
                        onValueChange={(value) => handleInputChange("listaChequeo", value)}
                        disabled={!isFormEditable}
                      >
                        <SelectTrigger className="text-black">
                          <SelectValue placeholder="Seleccione una lista" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">DATOS DEL SERVICIO</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-yellow-600 text-sm mt-2">
                        Esta lista de chequeo ya fue registrada para esta orden de trabajo
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-300">
                  <CardHeader>
                    <CardTitle className="text-black">Tiempos</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <Label className="text-black">Actividad</Label>
                        <div className="flex gap-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="mostrarTodo"
                              checked={formData.mostrarTodo}
                              onCheckedChange={(checked) => handleInputChange("mostrarTodo", checked)}
                              disabled={!isFormEditable}
                            />
                            <Label htmlFor="mostrarTodo" className="text-black">
                              Mostrar Todo
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="seleccionarTodo"
                              checked={formData.seleccionarTodo}
                              onCheckedChange={(checked) => {
                                handleInputChange("seleccionarTodo", checked)
                                handleSeleccionarTodo()
                              }}
                              disabled={!isFormEditable}
                            />
                            <Label htmlFor="seleccionarTodo" className="text-black">
                              Seleccionar Todo
                            </Label>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-2 max-h-80 overflow-y-auto border rounded-lg p-4">
                        <div className="font-bold text-black text-sm mb-2">CATEGORIA</div>
                        {actividades.map((actividad) => (
                          <div key={actividad.id} className="flex items-start space-x-2">
                            <Checkbox
                              id={`actividad-${actividad.id}`}
                              checked={actividadesSeleccionadas.includes(actividad.id)}
                              onCheckedChange={(checked) => handleActividadChange(actividad.id, checked as boolean)}
                              disabled={!isFormEditable}
                            />
                            <Label htmlFor={`actividad-${actividad.id}`} className="text-sm leading-tight text-black">
                              {actividad.nombre}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex flex-col md:flex-row gap-6">
                  <Card className="flex-1 border border-gray-300">
                    <CardHeader>
                      <CardTitle className="text-black">Firma del Cliente</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-col items-start">
                        <p className="text-sm text-black mb-2">Capture la firma del cliente</p>
                        <SignatureCapture
                          onSignatureSave={(data) => handleSignatureSave("client", data)}
                          currentSignature={clientSignature}
                          disabled={!isFormEditable}
                        />
                        {clientSignature && (
                          <div className="mt-4">
                            <p className="text-sm text-green-600 mb-2">Firma capturada</p>
                            <img
                              src={clientSignature || "/placeholder.svg"}
                              alt="Firma del cliente"
                              className="border border-gray-300 rounded max-w-[200px] max-h-[80px]"
                            />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="flex-1 border border-gray-300">
                    <CardHeader>
                      <CardTitle className="text-black">Firma del Técnico</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-col items-end">
                        <p className="text-sm text-black mb-2">Capture la firma del técnico responsable del servicio</p>
                        <SignatureCapture
                          onSignatureSave={(data) => handleSignatureSave("technician", data)}
                          currentSignature={technicianSignature}
                          disabled={!isFormEditable}
                        />
                        {technicianSignature && (
                          <div className="mt-4">
                            <p className="text-sm text-green-600 mb-2">Firma capturada</p>
                            <img
                              src={technicianSignature || "/placeholder.svg"}
                              alt="Firma del técnico"
                              className="border border-gray-300 rounded max-w-[200px] max-h-[80px]"
                            />
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card className="border border-gray-300">
                  <CardHeader>
                    <CardTitle className="text-black">Técnico</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-black">Técnico</Label>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="mostrarGrupo"
                            checked={formData.mostrarGrupo}
                            onCheckedChange={(checked) => handleInputChange("mostrarGrupo", checked)}
                            disabled={!isFormEditable}
                          />
                          <Label htmlFor="mostrarGrupo" className="text-black">
                            Mostrar técnicos del mismo grupo
                          </Label>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Select
                          value={formData.tecnicoSeleccionado}
                          onValueChange={(value) => handleInputChange("tecnicoSeleccionado", value)}
                          disabled={!isFormEditable}
                        >
                          <SelectTrigger className="flex-1 text-black">
                            <SelectValue placeholder="Seleccione un técnico" />
                          </SelectTrigger>
                          <SelectContent>
                            {tecnicos.map((tecnico) => (
                              <SelectItem key={tecnico.id} value={tecnico.id}>
                                {tecnico.nombre}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          onClick={handleAgregarTecnico}
                          disabled={!formData.tecnicoSeleccionado || !isFormEditable}
                        >
                          Agregar
                        </Button>
                      </div>
                    </div>
                    {tecnicosAsignados.length > 0 && (
                      <div>
                        <Label className="text-black mb-2 block">Técnicos Asignados</Label>
                        <div className="space-y-2">
                          {tecnicosAsignados.map((tecnico) => (
                            <div
                              key={tecnico.id}
                              className="flex items-center justify-between bg-gray-50 p-3 rounded-lg"
                            >
                              <span className="text-black font-medium">{tecnico.nombre}</span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEliminarTecnico(tecnico.id)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                disabled={!isFormEditable}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="border border-gray-300">
                  <CardHeader>
                    <CardTitle className="text-black">Evaluación</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-black">Persona Encuestada</Label>
                      <Input
                        value={formData.personaEncuestada}
                        onChange={(e) => handleInputChange("personaEncuestada", e.target.value)}
                        placeholder="Nombre de la persona encuestada"
                        className="text-black"
                        disabled={!isFormEditable}
                      />
                    </div>
                    <div>
                      <Label className="text-black">Encuesta</Label>
                      <Select
                        value={formData.tipoEvaluacion}
                        onValueChange={(value) => handleInputChange("tipoEvaluacion", value)}
                        disabled={!isFormEditable}
                      >
                        <SelectTrigger className="text-black">
                          <SelectValue placeholder="Seleccione una encuesta" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Evaluación Del Servicio</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm shadow-xl mt-6 border border-gray-300">
          <CardHeader>
            <CardTitle className="text-black">Opciones de Contenido PDF</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeClientEquipment"
                checked={pdfExportOptions.includeClientEquipment}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeClientEquipment: checked as boolean }))
                }
              />
              <Label htmlFor="includeClientEquipment" className="text-black">
                Detalles del Cliente y Equipo
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeServiceType"
                checked={pdfExportOptions.includeServiceType}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeServiceType: checked as boolean }))
                }
              />
              <Label htmlFor="includeServiceType" className="text-black">
                Tipo de Servicio
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeBasicInfo"
                checked={pdfExportOptions.includeBasicInfo}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeBasicInfo: checked as boolean }))
                }
              />
              <Label htmlFor="includeBasicInfo" className="text-black">
                Información Básica (Trabajos, Compromisos, Recomendaciones)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeTechnicians"
                checked={pdfExportOptions.includeTechnicians}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeTechnicians: checked as boolean }))
                }
              />
              <Label htmlFor="includeTechnicians" className="text-black">
                Técnicos Asignados
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeChecklistsActivities"
                checked={pdfExportOptions.includeChecklistsActivities}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeChecklistsActivities: checked as boolean }))
                }
              />
              <Label htmlFor="includeChecklistsActivities" className="text-black">
                Listas de Chequeo y Actividades
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeEvaluation"
                checked={pdfExportOptions.includeEvaluation}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeEvaluation: checked as boolean }))
                }
              />
              <Label htmlFor="includeEvaluation" className="text-black">
                Evaluación
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeTechnicianSignature"
                checked={pdfExportOptions.includeTechnicianSignature}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeTechnicianSignature: checked as boolean }))
                }
              />
              <Label htmlFor="includeTechnicianSignature" className="text-black">
                Firma del Técnico
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeClientSignature"
                checked={pdfExportOptions.includeClientSignature}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeClientSignature: checked as boolean }))
                }
              />
              <Label htmlFor="includeClientSignature" className="text-black">
                Firma del Cliente
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeDateTimeWithClientSignature"
                checked={pdfExportOptions.includeDateTimeWithClientSignature}
                onCheckedChange={(checked) =>
                  setPdfExportOptions((prev) => ({ ...prev, includeDateTimeWithClientSignature: checked as boolean }))
                }
              />
              <Label htmlFor="includeDateTimeWithClientSignature" className="text-black">
                Fecha y Hora (junto a firma del cliente)
              </Label>
            </div>
          </CardContent>
        </Card>

        <Separator className="my-6" />

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={handleSaveToDatabase}
            size="lg"
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
            disabled={!isFormEditable}
          >
            <Save className="w-5 h-5" />
            Guardar en Base de Datos
          </Button>
          <Button
            onClick={handleExportPDF}
            size="lg"
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
          >
            <Download className="h-5 w-5" />
            Exportar PDF
          </Button>
        </div>
      </div>

      <div id="pdf-full-report-content" style={{ position: "absolute", left: "-9999px", top: 0, width: "210mm" }}>
        <PdfReportContent
          formData={formData}
          technicianSignature={technicianSignature || ""}
          clientSignature={clientSignature || ""}
          tecnicosAsignados={tecnicosAsignados}
          actividadesSeleccionadas={actividadesSeleccionadas}
          actividadesList={actividades}
          pdfExportOptions={pdfExportOptions}
        />
      </div>
    </div>
  )
}
