"use client"

import type React from "react"
import { useRef, useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"

interface SignatureCaptureProps {
  onSignatureSave: (signatureData: string) => void
  currentSignature: string
  disabled?: boolean // New prop
}

export default function SignatureCapture({ onSignatureSave, currentSignature, disabled }: SignatureCaptureProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [drawing, setDrawing] = useState(false)

  const getCanvasContext = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const ctx = canvas.getContext("2d")
    if (ctx) {
      ctx.lineWidth = 2
      ctx.lineCap = "round"
      ctx.strokeStyle = "#000"
    }
    return ctx
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas) {
      const ctx = getCanvasContext()
      if (ctx) {
        canvas.width = canvas.offsetWidth
        canvas.height = canvas.offsetHeight
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        if (currentSignature) {
          const img = new Image()
          img.src = currentSignature
          img.onload = () => {
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
          }
        }
      }
    }
  }, [currentSignature, getCanvasContext])

  const startDrawing = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      if (disabled) return // Prevent drawing if disabled
      const ctx = getCanvasContext()
      if (!ctx) return
      setDrawing(true)
      const clientX = "touches" in e ? e.touches[0].clientX : e.clientX
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY
      const canvas = canvasRef.current!
      const rect = canvas.getBoundingClientRect()
      ctx.beginPath()
      ctx.moveTo(clientX - rect.left, clientY - rect.top)
    },
    [getCanvasContext, disabled],
  )

  const draw = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      if (!drawing || disabled) return // Prevent drawing if disabled
      const ctx = getCanvasContext()
      if (!ctx) return
      if ("touches" in e) {
        e.preventDefault()
      }
      const clientX = "touches" in e ? e.touches[0].clientX : e.clientX
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY
      const canvas = canvasRef.current!
      const rect = canvas.getBoundingClientRect()
      ctx.lineTo(clientX - rect.left, clientY - rect.top)
      ctx.stroke()
    },
    [drawing, getCanvasContext, disabled],
  )

  const stopDrawing = useCallback(() => {
    if (disabled) return // Prevent saving if disabled
    setDrawing(false)
    const canvas = canvasRef.current
    if (canvas) {
      onSignatureSave(canvas.toDataURL())
    }
  }, [onSignatureSave, disabled])

  const clearSignature = useCallback(() => {
    if (disabled) return // Prevent clearing if disabled
    const ctx = getCanvasContext()
    if (ctx && canvasRef.current) {
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)
      onSignatureSave("")
    }
  }, [onSignatureSave, getCanvasContext, disabled])

  return (
    <div className="flex flex-col items-center gap-2 w-full">
      <canvas
        ref={canvasRef}
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseOut={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
        className={`border border-gray-300 rounded-lg w-full h-[150px] bg-white ${disabled ? "cursor-not-allowed opacity-70" : "cursor-crosshair"}`}
      />
      <div className="flex gap-2">
        <Button onClick={clearSignature} variant="outline" disabled={disabled}>
          Limpiar Firma
        </Button>
      </div>
    </div>
  )
}
