import { createServerClient, type CookieOptions } from "@supabase/ssr"
import { cookies } from "next/headers"

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || "http://localhost:54321"
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "public-anon-key"

if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
  console.warn(
    "⚠️  Supabase env-vars are missing – running in offline/preview mode. " + "Database calls will be skipped.",
  )
}

export function createServerSupabaseClient() {
  const cookieStore = cookies()

  return createServerClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value
      },
      set(name: string, value: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value, ...options })
        } catch (error) {
          // The `cookies()` may not be available in a Server Component context.
          // If this happens, you can ignore this error or log it.
          console.warn("Could not set cookie in Server Component:", error)
        }
      },
      remove(name: string, options: CookieOptions) {
        try {
          cookieStore.set({ name, value: "", ...options })
        } catch (error) {
          console.warn("Could not remove cookie in Server Component:", error)
        }
      },
    },
  })
}

// createServerSupabaseAdminClient is no longer needed as Clerk handles admin user management
// and direct DB access for profiles is via Neon client.
// If you need admin access to other Supabase tables, you'd re-add this.
