"use client"

import { useState, useEffect } from "react"
import KaikaReportForm from "../kaika-report-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { getReportByNumber } from "@/app/actions"
import { getUserSession } from "@/app/auth/actions" // Still used to get profile from Neon
import { toast } from "sonner"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { SignOutButton } from "@clerk/nextjs" // Import Clerk's SignOutButton

export default function DashboardPage() {
  const router = useRouter()
  const [showForm, setShowForm] = useState(false)
  const [reportNumberToConsult, setReportNumberToConsult] = useState("")
  const [initialReportData, setInitialReportData] = useState<any>(null)
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [loadingUser, setLoadingUser] = useState(true)
  const [isNewReportMode, setIsNewReportMode] = useState(false)

  useEffect(() => {
    async function fetchUser() {
      const userSession = await getUserSession() // This now fetches Clerk user ID and Neon profile
      setCurrentUser(userSession)
      setLoadingUser(false)
    }
    fetchUser()
  }, [])

  const handleConsultReport = async () => {
    if (!reportNumberToConsult || reportNumberToConsult.length !== 8 || !/^\d{8}$/.test(reportNumberToConsult)) {
      toast.error("Por favor ingrese un número de reporte de 8 dígitos válido para consultar.")
      return
    }

    const confirmSearch = confirm(`¿Está seguro que desea consultar el reporte número ${reportNumberToConsult}?`)
    if (!confirmSearch) {
      toast.info("Consulta cancelada.")
      return
    }

    const result = await getReportByNumber(reportNumberToConsult)
    if (result.success) {
      // Determine if the current user can edit this report
      const canEdit = currentUser?.profile?.role === "admin" || currentUser?.clerkUser?.id === result.data.userId
      // Pass this information to the form component
      setInitialReportData({ ...result.data, canEdit })
      setShowForm(true)
      setIsNewReportMode(false) // Not a new report
      toast.success("Reporte cargado correctamente.")
    } else {
      if (result.message.includes("Reporte no encontrado")) {
        toast.error("Reporte no encontrado. Verifique el número e intente de nuevo.")
      } else {
        toast.error(result.message)
      }
      setInitialReportData(null)
    }
  }

  const handleOpenNewReport = () => {
    setInitialReportData(null) // Clear initial data for a new form
    setShowForm(true)
    setIsNewReportMode(true) // It's a new report
  }

  const handleBackToDashboard = () => {
    setShowForm(false)
    setInitialReportData(null)
    setIsNewReportMode(false)
    setReportNumberToConsult("") // Clear consultation input
  }

  if (loadingUser) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 flex items-center justify-center p-6">
        <p className="text-white text-lg">Cargando usuario...</p>
      </div>
    )
  }

  if (showForm) {
    return (
      <KaikaReportForm
        onBack={handleBackToDashboard}
        initialData={initialReportData}
        currentUserId={currentUser?.clerkUser?.id} // Use Clerk's user ID
        isNewReport={isNewReportMode}
        isAdmin={currentUser?.profile?.role === "admin"}
      />
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 flex flex-col items-center justify-center p-6 text-center">
      <Image
        src="/images/kaika-logo.png"
        alt="Kaika Logo"
        width={294}
        height={148}
        className="mx-auto mb-4 object-contain"
      />
      <h1 className="text-4xl font-bold text-white mb-4">Dashboard de Reportes Kaika</h1>
      <p className="text-blue-100 mb-8">
        Bienvenido, {currentUser?.clerkUser?.emailAddresses[0]?.emailAddress} ({currentUser?.profile?.role})
      </p>

      <div className="flex flex-col sm:flex-row gap-4 items-center justify-center mb-8">
        <Button onClick={handleOpenNewReport} size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
          Abrir Nuevo Reporte de Servicio
        </Button>
        <div className="flex items-center gap-2">
          <Input
            type="text"
            value={reportNumberToConsult}
            onChange={(e) => {
              const value = e.target.value
              if (/^\d*$/.test(value) && value.length <= 8) {
                setReportNumberToConsult(value)
              }
            }}
            placeholder="No. Reporte (8 dígitos)"
            maxLength={8}
            className="w-40 text-black"
          />
          <Button onClick={handleConsultReport} size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
            Consultar Reporte
          </Button>
        </div>
      </div>

      {currentUser?.profile?.role === "admin" && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold text-white mb-4">Administración</h2>
          <Button
            onClick={() => router.push("/admin/users")}
            size="lg"
            className="bg-purple-600 text-white hover:bg-purple-700"
          >
            Gestionar Usuarios
          </Button>
        </div>
      )}

      <SignOutButton signOutCallback={() => toast.success("Sesión cerrada correctamente.")}>
        <Button variant="ghost" className="text-white hover:bg-blue-700 mt-12">
          Cerrar Sesión
        </Button>
      </SignOutButton>
    </div>
  )
}
