"use server"

import type { NeonQueryFunction } from "@neondatabase/serverless"
import { auth } from "@clerk/nextjs/server" // Import Clerk's server-side auth helper

// ——————————————————————————————————————————————
//  Cargar Neon sólo en el servidor (evita 'global')
// ——————————————————————————————————————————————

let _sql: NeonQueryFunction | null = null
async function getSql(): Promise<NeonQueryFunction | null> {
  // En el navegador no hay conexión a BD.
  if (typeof window !== "undefined") return null

  if (_sql) return _sql
  const { neon } = await import("@neondatabase/serverless")
  const connectionString = process.env.POSTGRES_URL ?? ""
  if (!connectionString) return null

  // Reutilizamos singleton en el ámbito global.
  const g = globalThis as Record<string, any>
  _sql = g.__kaika_neon ??= neon(connectionString)
  return _sql
}

interface ReportData {
  formData: any
  technicianSignature: string
  clientSignature: string
  tecnicosAsignados: any[]
  actividadesSeleccionadas: string[]
  reportId?: string // Optional for updating existing reports
}

export async function saveReport(reportData: ReportData) {
  const { formData, technicianSignature, clientSignature, tecnicosAsignados, actividadesSeleccionadas, reportId } =
    reportData
  const { reportNumber } = formData

  const { userId } = auth() // Get Clerk's userId

  if (!userId) {
    return { success: false, message: "No autenticado." }
  }

  if (!reportNumber || !/^\d{8}$/.test(reportNumber)) {
    return { success: false, message: "El número de reporte debe ser de 8 dígitos numéricos." }
  }

  // Check user role for update permissions
  if (reportId) {
    // This is an update operation
    const sql = await getSql()
    let profile = null
    if (sql) {
      try {
        const profilesResult = await sql`
        SELECT role
        FROM public.profiles
        WHERE id = ${userId}
      `
        if (profilesResult.length > 0) {
          profile = profilesResult[0]
        }
      } catch (profileError) {
        console.error("Error checking profile role from Neon:", profileError)
        return { success: false, message: "Error al verificar permisos." }
      }
    } else {
      console.warn("In-memory mode: Cannot check profile role. Requires DATABASE_URL.")
      profile = { role: "technician" } // Assume technician for preview
    }

    if (profile?.role !== "admin") {
      // For technicians, only allow update if they are the original creator
      const sql = await getSql()
      let existingReport = null
      if (sql) {
        try {
          const reportRows = await sql`
          SELECT user_id
          FROM reports
          WHERE id = ${reportId}
        `
          if (reportRows.length > 0) {
            existingReport = reportRows[0]
          }
        } catch (reportError) {
          console.error("Error fetching existing report from Neon:", reportError)
          return { success: false, message: "Reporte no encontrado o error de acceso." }
        }
      } else {
        console.warn("In-memory mode: Cannot check existing report owner. Requires DATABASE_URL.")
        // In preview, assume editable if no DB
        existingReport = { user_id: userId }
      }

      if (existingReport?.user_id !== userId) {
        return { success: false, message: "No tiene permiso para modificar este reporte." }
      }
    }
  }

  // ---------- in-memory preview ----------
  const sql = await getSql()
  const memoryStore = new Map<string, any>() // <reportNumber, full row>
  if (!sql) {
    // In-memory does not handle user_id or reportId properly, simple overwrite
    memoryStore.set(reportNumber, {
      formData,
      technicianSignature,
      clientSignature,
      tecnicosAsignados,
      actividadesSeleccionadas,
      user_id: userId,
      updated_at: new Date().toISOString(),
    })
    return { success: true, message: "Reporte guardado en memoria (preview)." }
  }
  // ---------- real database ----------
  try {
    if (reportId) {
      // Update existing report
      await sql`
      UPDATE reports
      SET
        form_data            = ${JSON.stringify(formData)}::jsonb,
        technician_signature = ${technicianSignature},
        client_signature     = ${clientSignature},
        assigned_technicians = ${JSON.stringify(tecnicosAsignados)}::jsonb,
        selected_activities  = ${JSON.stringify(actividadesSeleccionadas)}::jsonb,
        updated_at           = NOW()
      WHERE id                = ${reportId}
    `
      return { success: true, message: "Reporte actualizado correctamente." }
    } else {
      // Insert new report
      const exists =
        (
          await sql`
          SELECT 1 FROM reports WHERE report_number = ${reportNumber} LIMIT 1
        `
        ).length > 0

      if (exists) {
        return {
          success: false,
          message: `El número de reporte ${reportNumber} ya existe. Use un número diferente o consulte el reporte existente.`,
        }
      }

      const rows = await sql`
      INSERT INTO reports (
        report_number,
        form_data,
        technician_signature,
        client_signature,
        assigned_technicians,
        selected_activities,
        user_id
      ) VALUES (
        ${reportNumber},
        ${JSON.stringify(formData)}::jsonb,
        ${technicianSignature},
        ${clientSignature},
        ${JSON.stringify(tecnicosAsignados)}::jsonb,
        ${JSON.stringify(actividadesSeleccionadas)}::jsonb,
        ${userId}
      ) RETURNING id
    `
      return { success: true, message: "Reporte guardado correctamente.", reportId: rows[0].id }
    }
  } catch (err) {
    console.error("DB save error:", err)
    return { success: false, message: "Error al guardar el reporte en la base de datos." }
  }
}

export async function getReportByNumber(reportNumber: string) {
  if (!/^\d{8}$/.test(reportNumber)) {
    return { success: false, message: "Número de reporte inválido." }
  }

  const { userId } = auth() // Get Clerk's userId

  if (!userId) {
    return { success: false, message: "No autenticado." }
  }

  // ---------- in-memory preview ----------
  const sql = await getSql()
  const memoryStore = new Map<string, any>() // <reportNumber, full row>
  if (!sql) {
    const row = memoryStore.get(reportNumber)
    if (!row) return { success: false, message: "Reporte no encontrado (preview)." }
    return {
      success: true,
      data: {
        formData: row.formData,
        technicianSignature: row.technicianSignature,
        clientSignature: row.clientSignature,
        tecnicosAsignados: row.tecnicosAsignados,
        actividadesSeleccionadas: row.actividadesSeleccionadas,
        userId: row.user_id, // Include user_id
      },
    }
  }

  // ---------- real database ----------
  try {
    const rows = await sql`
    SELECT
      id, -- Include id for update operations
      form_data,
      technician_signature,
      client_signature,
      assigned_technicians,
      selected_activities,
      user_id
    FROM reports
    WHERE report_number = ${reportNumber}
  `
    if (!rows.length) return { success: false, message: "Reporte no encontrado." }

    const r = rows[0]
    return {
      success: true,
      data: {
        id: r.id, // Pass report ID
        formData: r.form_data,
        technicianSignature: r.technician_signature,
        clientSignature: r.client_signature,
        tecnicosAsignados: r.assigned_technicians,
        actividadesSeleccionadas: r.selected_activities,
        userId: r.user_id, // Include user_id
      },
    }
  } catch (err) {
    console.error("DB fetch error:", err)
    return { success: false, message: "Error al consultar el reporte en la base de datos." }
  }
}
