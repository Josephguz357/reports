"use client"

import { UserProfile, useUser } from "@clerk/nextjs"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { updateFirstLoginStatus } from "@/app/auth/actions" // New action to update first_login in Neon
import Image from "next/image"

export default function ChangePasswordPage() {
  const { user, isLoaded } = useUser()
  const router = useRouter()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function checkFirstLogin() {
      if (!isLoaded) return

      if (!user) {
        router.push("/login")
        return
      }

      // Check first_login status from Neon via server action
      const profileResult = await updateFirstLoginStatus(user.id, false) // Attempt to set first_login to false
      if (profileResult.success) {
        // If successfully updated (meaning it was true and now false), redirect
        router.push("/dashboard")
      } else {
        // If it failed, it might mean it was already false or an error occurred.
        // For now, we'll let them see the profile page.
        console.warn("Could not update first_login status:", profileResult.message)
      }
      setLoading(false)
    }
    checkFirstLogin()
  }, [isLoaded, user, router])

  if (loading || !isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600">
        <p className="text-white text-lg">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 p-4">
      <div className="w-full max-w-md bg-white/95 backdrop-blur-sm shadow-xl rounded-lg p-6">
        <div className="text-center mb-6">
          <Image
            src="/images/kaika-logo.png"
            alt="Kaika Logo"
            width={294}
            height={148}
            className="mx-auto mb-4 object-contain"
          />
          <h1 className="text-2xl font-bold text-black">Gestionar Perfil</h1>
          <p className="text-gray-600">Es su primer inicio de sesión o necesita actualizar su información.</p>
        </div>
        <UserProfile path="/change-password" routing="path" />
      </div>
    </div>
  )
}
