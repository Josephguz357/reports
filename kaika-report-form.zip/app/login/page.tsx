"use client"

import { SignIn } from "@clerk/nextjs"
import Image from "next/image"

export default function LoginPage() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 p-4">
      <div className="w-full max-w-md bg-white/95 backdrop-blur-sm shadow-xl rounded-lg p-6">
        <div className="text-center mb-6">
          <Image
            src="/images/kaika-logo.png"
            alt="Kaika Logo"
            width={294}
            height={148}
            className="mx-auto mb-4 object-contain"
          />
          <h1 className="text-2xl font-bold text-black">Iniciar Sesión</h1>
          <p className="text-gray-600">Ingrese sus credenciales para acceder al sistema.</p>
        </div>
        <SignIn appearance={{ variables: { colorPrimary: "#2563eb" } }} />
      </div>
    </div>
  )
}
