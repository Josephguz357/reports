"use client"

import { useState } from "react"
import KaikaReportForm from "./kaika-report-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { getReportByNumber } from "./actions" // Import the server action
import { toast } from "sonner"
import { redirect } from "next/navigation"

export default function Home() {
  redirect("/dashboard")

  const [showForm, setShowForm] = useState(false)
  const [reportNumberToConsult, setReportNumberToConsult] = useState("")
  const [initialReportData, setInitialReportData] = useState<any>(null)

  const handleConsultReport = async () => {
    if (!reportNumberToConsult || reportNumberToConsult.length !== 8 || !/^\d{8}$/.test(reportNumberToConsult)) {
      toast.error("Por favor ingrese un número de reporte de 8 dígitos válido para consultar.")
      return
    }

    // Confirmation dialog
    const confirmSearch = confirm(`¿Está seguro que desea consultar el reporte número ${reportNumberToConsult}?`)
    if (!confirmSearch) {
      toast.info("Consulta cancelada.")
      return
    }

    const result = await getReportByNumber(reportNumberToConsult)
    if (result.success) {
      setInitialReportData(result.data)
      setShowForm(true)
      toast.success("Reporte cargado correctamente.")
    } else {
      // Differentiate between "not found" and "connection error"
      if (result.message.includes("Reporte no encontrado")) {
        toast.error("Reporte no encontrado. Verifique el número e intente de nuevo.")
      } else if (result.message.includes("Error al consultar el reporte en la base de datos")) {
        toast.error("No fue posible conectarse a la base de datos. Por favor, intente más tarde.")
      } else {
        toast.error(result.message) // Generic error for other cases
      }
      setInitialReportData(null) // Clear any previous data
    }
  }

  if (showForm) {
    return <KaikaReportForm onBack={() => setShowForm(false)} initialData={initialReportData} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 via-blue-500 to-blue-600 flex items-center justify-center p-6">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Dashboard</h1>
        <p className="text-blue-100 mb-8">Sistema de Gestión de Reportes de Servicio</p>
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-center mb-8">
          <Button
            onClick={() => {
              setInitialReportData(null) // Clear initial data for a new form
              setShowForm(true)
            }}
            size="lg"
            className="bg-white text-blue-600 hover:bg-blue-50"
          >
            Abrir Nuevo Reporte de Servicio
          </Button>
          <div className="flex items-center gap-2">
            <Input
              type="text"
              value={reportNumberToConsult}
              onChange={(e) => {
                const value = e.target.value
                if (/^\d*$/.test(value) && value.length <= 8) {
                  setReportNumberToConsult(value)
                }
              }}
              placeholder="No. Reporte (8 dígitos)"
              maxLength={8}
              className="w-40 text-black"
            />
            <Button onClick={handleConsultReport} size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
              Consultar Reporte
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
