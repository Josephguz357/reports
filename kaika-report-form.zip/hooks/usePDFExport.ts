import html2canvas from "html2canvas"
import jsPDF from "jspdf"
import { toast } from "sonner"

interface PDFExportOptions {
  [key: string]: any // Allows for any additional data
}

export function usePDFExport() {
  const exportToPDF = async (elementIds: string[], filename: string, options: PDFExportOptions = {}) => {
    try {
      if (elementIds.length === 0) {
        toast.error("No se especificaron elementos para exportar.")
        return false
      }

      // We will only process the first element ID, assuming it contains the full report
      const element = document.getElementById(elementIds[0])
      if (!element) {
        console.warn(`Element with ID ${elementIds[0]} not found. Skipping.`)
        return false
      }

      // Clonar el elemento para renderizarlo fuera de pantalla sin interferir con el diseño
      const clonedElement = element.cloneNode(true) as HTMLElement
      clonedElement.style.position = "absolute"
      clonedElement.style.top = "-9999px"
      clonedElement.style.left = "-9999px"
      clonedElement.style.width = "210mm" // Ensure it renders at A4 width for consistent scaling
      clonedElement.style.background = "white" // Ensure white background for clarity

      // Añadir al cuerpo temporalmente
      document.body.appendChild(clonedElement)

      const canvas = await html2canvas(clonedElement, {
        scale: 2, // Aumentar la escala para mejor resolución
        useCORS: true, // Importante para imágenes, ej. firma
        allowTaint: true, // Permitir que el lienzo se "contamine" con imágenes de origen cruzado (ej. placeholder.svg)
      })

      // Eliminar el elemento clonado del cuerpo
      document.body.removeChild(clonedElement)

      const imgData = canvas.toDataURL("image/png")

      const a4Width = 210 // Ancho de una página A4 en mm
      const padding = 10 // Padding around the content on the PDF page

      // Calculate image dimensions in mm based on A4 width and aspect ratio
      const imgWidth = a4Width - 2 * padding
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      // Create a new jsPDF instance with a custom height to fit the entire content
      const pdf = new jsPDF("p", "mm", [a4Width, imgHeight + 2 * padding])

      // Add the single, continuous image to the PDF
      pdf.addImage(imgData, "PNG", padding, padding, imgWidth, imgHeight)

      pdf.save(`${filename}.pdf`)
      return true
    } catch (error) {
      console.error("Error exporting PDF:", error)
      toast.error("Error al exportar PDF: " + (error as Error).message)
      return false
    }
  }

  return { exportToPDF }
}
