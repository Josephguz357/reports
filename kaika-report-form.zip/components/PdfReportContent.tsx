import Image from "next/image"

interface PdfReportContentProps {
  formData: any
  technicianSignature: string
  clientSignature: string
  tecnicosAsignados: { id: string; nombre: string }[]
  actividadesSeleccionadas: string[]
  actividadesList: { id: string; nombre: string; categoria: string; seleccionada: boolean }[]
  pdfExportOptions: {
    includeClientEquipment: boolean
    includeServiceType: boolean
    includeBasicInfo: boolean
    includeTechnicians: boolean
    includeChecklistsActivities: boolean
    includeEvaluation: boolean
    includeTechnicianSignature: boolean
    includeClientSignature: boolean
    includeDateTimeWithClientSignature: boolean
  }
}

export default function PdfReportContent({
  formData,
  technicianSignature,
  clientSignature,
  tecnicosAsignados,
  actividadesSeleccionadas,
  actividadesList,
  pdfExportOptions,
}: PdfReportContentProps) {
  const selectedActivitiesDetails = actividadesList.filter((activity) => actividadesSeleccionadas.includes(activity.id))

  return (
    <div className="p-8 bg-white text-black font-sans text-sm leading-normal w-[210mm] min-h-[297mm]">
      {" "}
      {/* A4 size */}
      <div className="flex justify-between items-center mb-4">
        {/* Left: Logo */}
        <Image
          src="/images/kaika-logo.png"
          alt="Kaika Logo"
          width={368} // 294 * 1.25 = 367.5 -> 368
          height={185} // 148 * 1.25 = 147.5 -> 185
          className="object-contain"
        />
        {/* Right: Report Number and Title */}
        <div className="flex flex-col items-end">
          {formData.reportNumber && <p className="text-sm font-bold mb-1">No. Reporte: {formData.reportNumber}</p>}
          <h1 className="text-xl font-bold">REPORTE DE SERVICIO</h1>
        </div>
      </div>
      <hr className="mb-4" />
      {/* Client and Equipment Details */}
      {pdfExportOptions.includeClientEquipment && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Detalles del Cliente y Equipo</h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            <p>
              <strong>CLIENTE:</strong> {formData.clienteNombre}
            </p>
            <p>
              <strong>TELEFONO:</strong> {formData.clienteTelefono}
            </p>
            <p>
              <strong>E-MAIL:</strong> {formData.clienteEmail}
            </p>
            <p>
              <strong>EQUIPO:</strong> {formData.equipoNombre}
            </p>
            <p>
              <strong>MODELO:</strong> {formData.equipoModelo}
            </p>
            <p>
              <strong>MARCA:</strong> {formData.equipoMarca}
            </p>
            <p>
              <strong>SERIAL:</strong> {formData.equipoSerial}
            </p>
            <p>
              <strong>No. INV:</strong> {formData.equipoNoInv}
            </p>
            <p>
              <strong>UBICACION:</strong> {formData.equipoUbicacion}
            </p>
            <p>
              <strong>ORDEN DE CLIENTE No.:</strong> {formData.ordenClienteNo}
            </p>
            <p className="col-span-2">
              <strong>ENCARGADO:</strong> {formData.encargado}
            </p>
          </div>
        </div>
      )}
      {/* Service Type */}
      {pdfExportOptions.includeServiceType && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Tipo de Servicio</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-x-4 gap-y-1">
            {Object.entries(formData.serviceTypes).map(
              ([key, value]) => value && <p key={key}>- {key.replace(/([A-Z])/g, " $1").toUpperCase()}</p>,
            )}
          </div>
        </div>
      )}
      {/* Basic Information (Trabajos, Compromisos, Recomendaciones) */}
      {pdfExportOptions.includeBasicInfo && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Información Básica</h2>
          <p className="mb-2">
            <strong>Trabajos Realizados:</strong>
          </p>
          <div className="border p-2 min-h-[50px] whitespace-pre-wrap">{formData.trabajos}</div>
          <p className="mt-2 mb-2">
            <strong>Compromisos:</strong>
          </p>
          <div className="border p-2 min-h-[50px] whitespace-pre-wrap">{formData.compromisos}</div>
          <p className="mt-2 mb-2">
            <strong>Recomendaciones:</strong>
          </p>
          <div className="border p-2 min-h-[50px] whitespace-pre-wrap">{formData.recomendaciones}</div>
        </div>
      )}
      {/* Technicians */}
      {pdfExportOptions.includeTechnicians && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Técnicos Asignados</h2>
          {tecnicosAsignados.length > 0 ? (
            <ul>
              {tecnicosAsignados.map((tecnico) => (
                <li key={tecnico.id}>- {tecnico.nombre}</li>
              ))}
            </ul>
          ) : (
            <p>No hay técnicos asignados.</p>
          )}
        </div>
      )}
      {/* Checklists and Activities */}
      {pdfExportOptions.includeChecklistsActivities && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Actividades Realizadas</h2>
          {selectedActivitiesDetails.length > 0 ? (
            <ul>
              {selectedActivitiesDetails.map((actividad) => (
                <li key={actividad.id}>- {actividad.nombre}</li>
              ))}
            </ul>
          ) : (
            <p>No hay actividades seleccionadas.</p>
          )}
        </div>
      )}
      {/* Evaluation */}
      {pdfExportOptions.includeEvaluation && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Evaluación</h2>
          <p>
            <strong>Persona Encuestada:</strong> {formData.personaEncuestada}
          </p>
          <p>
            <strong>Tipo de Evaluación:</strong> {formData.tipoEvaluacion === "1" ? "Evaluación Del Servicio" : "N/A"}
          </p>
        </div>
      )}
      {/* Technician Signature */}
      {pdfExportOptions.includeTechnicianSignature && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Firma del Técnico</h2>
          {technicianSignature ? (
            <img
              src={technicianSignature || "/placeholder.svg"}
              alt="Firma del técnico"
              className="border border-gray-300 max-w-[250px] max-h-[100px]"
            />
          ) : (
            <p>No se ha capturado la firma del técnico.</p>
          )}
        </div>
      )}
      {/* Client Signature and Date/Time */}
      {(pdfExportOptions.includeClientSignature || pdfExportOptions.includeDateTimeWithClientSignature) && (
        <div className="flex justify-between items-start gap-4">
          {pdfExportOptions.includeClientSignature && (
            <div className="flex-1">
              <h2 className="text-lg font-semibold mb-2">Firma del Cliente</h2>
              {clientSignature ? (
                <img
                  src={clientSignature || "/placeholder.svg"}
                  alt="Firma del cliente"
                  className="border border-gray-300 max-w-[250px] max-h-[100px]"
                />
              ) : (
                <p>No se ha capturado la firma del cliente.</p>
              )}
            </div>
          )}
          {pdfExportOptions.includeDateTimeWithClientSignature && (
            <div className="flex-1 text-right">
              <h2 className="text-lg font-semibold mb-2">Fecha y Hora del Servicio</h2>
              <p>
                <strong>Inicio:</strong> {formData.fechaInicio} {formData.horaInicio}
              </p>
              <p>
                <strong>Fin:</strong> {formData.fechaFin} {formData.horaFin}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
