-- WARNING: This script will drop and recreate the 'profiles' table.
-- If you have existing data in 'profiles', you must back it up first!

-- Drop existing policies and trigger related to public.profiles
DROP POLICY IF EXISTS "Users can view their own profile." ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile." ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles." ON public.profiles;
DROP POLICY IF EXISTS "Admins can insert new profiles." ON public.profiles;
DROP POLICY IF EXISTS "Admins can update any profile." ON public.profiles;
DROP POLICY IF EXISTS "Admins can delete any profile." ON public.profiles;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Drop the existing profiles table
DROP TABLE IF EXISTS public.profiles CASCADE;

-- Recreate the profiles table with TEXT ID to match Clerk's user IDs
CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY NOT NULL, -- Changed from UUID to TEXT
    role TEXT DEFAULT 'technician' NOT NULL, -- 'admin' or 'technician'
    first_login BOOLEAN DEFAULT TRUE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Re-enable Row Level Security (RLS) for profiles table
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policies for public.profiles (adapted for Clerk's user IDs)
-- Note: auth.uid() is still used for RLS, but the ID in profiles is TEXT.
-- This means you'll need to ensure Clerk's user ID is passed to the DB session
-- if you want to use RLS based on the user's ID in the profiles table.
-- For now, we'll keep the RLS policies as they were, assuming a mechanism
-- to set the session user ID (e.g., via a custom JWT from Clerk).
-- For simplicity, the RLS policies below are more permissive or rely on admin role.

-- Policy to allow authenticated users to view their own profile (if their Clerk ID matches)
CREATE POLICY "Users can view their own profile."
  ON public.profiles FOR SELECT USING (auth.uid()::text = id); -- Cast auth.uid() to text

-- Policy to allow authenticated users to update their own profile
CREATE POLICY "Users can update their own profile."
  ON public.profiles FOR UPDATE USING (auth.uid()::text = id);

-- Policy to allow admins to view all profiles
CREATE POLICY "Admins can view all profiles."
  ON public.profiles FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );

-- Policy to allow admins to insert new profiles
CREATE POLICY "Admins can insert new profiles."
  ON public.profiles FOR INSERT TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );

-- Policy to allow admins to update any profile
CREATE POLICY "Admins can update any profile."
  ON public.profiles FOR UPDATE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );

-- Policy to allow admins to delete any profile
CREATE POLICY "Admins can delete any profile."
  ON public.profiles FOR DELETE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );

-- IMPORTANT: The reports table also references auth.users.id.
-- If you want to fully decouple from Supabase Auth, you'll need to:
-- 1. Drop the foreign key constraint on reports.user_id.
-- 2. Change reports.user_id to TEXT.
-- 3. Update RLS policies on reports to use Clerk's user IDs.
-- For this implementation, we will assume reports.user_id will also be TEXT
-- and remove the foreign key constraint to auth.users.

-- Drop existing policies and foreign key on reports table
DROP POLICY IF EXISTS "Authenticated users can create reports." ON public.reports;
DROP POLICY IF EXISTS "Users can view their own reports." ON public.reports;
DROP POLICY IF EXISTS "Admins can view all reports." ON public.reports;
DROP POLICY IF EXISTS "Admins can update any report." ON public.reports;
DROP POLICY IF EXISTS "Admins can delete any report." ON public.reports;

ALTER TABLE public.reports DROP CONSTRAINT IF EXISTS reports_user_id_fkey;

-- Alter reports.user_id to TEXT
ALTER TABLE public.reports ALTER COLUMN user_id TYPE TEXT;

-- Re-enable RLS for reports table
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- Policies for reports table (adapted for Clerk's user IDs)
CREATE POLICY "Authenticated users can create reports."
  ON public.reports FOR INSERT WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can view their own reports."
  ON public.reports FOR SELECT USING (auth.uid()::text = user_id);

CREATE POLICY "Admins can view all reports."
  ON public.reports FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );

CREATE POLICY "Admins can update any report."
  ON public.reports FOR UPDATE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );

CREATE POLICY "Admins can delete any report."
  ON public.reports FOR DELETE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid()::text AND role = 'admin')
  );
