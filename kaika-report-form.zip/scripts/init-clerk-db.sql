-- This script sets up the database schema for Clerk authentication with Neon.
-- It removes all Supabase-specific RLS policies and triggers,
-- relying on application-level authorization via Clerk and Next.js Server Actions.

-- Drop existing policies and trigger related to public.profiles (if they exist from previous runs)
DROP POLICY IF EXISTS "Users can view their own profile." ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile." ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles." ON public.profiles;
DROP POLICY IF EXISTS "Admins can insert new profiles." ON public.profiles;
DROP POLICY IF EXISTS "Admins can update any profile." ON public.profiles;
DROP POLICY IF EXISTS "Admins can delete any profile." ON public.profiles;
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users; -- This trigger is for Supabase Auth
DROP FUNCTION IF EXISTS public.handle_new_user(); -- This function is for Supabase Auth

-- Drop the existing profiles table if it exists, to ensure a clean slate
DROP TABLE IF EXISTS public.profiles CASCADE;

-- Recreate the profiles table with TEXT ID to match Clerk's user IDs
CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY NOT NULL, -- Changed from UUID to TEXT to store Clerk user IDs
    role TEXT DEFAULT 'technician' NOT NULL, -- 'admin' or 'technician'
    first_login BOOLEAN DEFAULT TRUE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- IMPORTANT: Row Level Security is DISABLED for public.profiles.
-- Authorization will be handled in the application layer (Next.js Server Actions)
-- using Clerk's server-side authentication.
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;


-- Drop existing policies on reports table (if they exist from previous runs)
DROP POLICY IF EXISTS "Authenticated users can create reports." ON public.reports;
DROP POLICY IF EXISTS "Users can view their own reports." ON public.reports;
DROP POLICY IF EXISTS "Admins can view all reports." ON public.reports;
DROP POLICY IF EXISTS "Admins can update any report." ON public.reports;
DROP POLICY IF EXISTS "Admins can delete any report." ON public.reports;

-- Drop the existing reports table if it exists, to ensure a clean slate
DROP TABLE IF EXISTS public.reports CASCADE;

-- Create reports table (ensure user_id is TEXT)
CREATE TABLE IF NOT EXISTS reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    report_number VARCHAR(8) UNIQUE NOT NULL,
    form_data JSONB NOT NULL,
    technician_signature TEXT,
    client_signature TEXT,
    assigned_technicians JSONB,
    selected_activities JSONB,
    user_id TEXT NOT NULL, -- Changed from UUID to TEXT, no longer references auth.users
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Optional: Add an index for faster lookups by report_number
CREATE INDEX IF NOT EXISTS idx_report_number ON reports (report_number);

-- IMPORTANT: Row Level Security is DISABLED for public.reports.
-- Authorization will be handled in the application layer (Next.js Server Actions)
-- using Clerk's server-side authentication.
ALTER TABLE public.reports DISABLE ROW LEVEL SECURITY;

-- Ensure uuid-ossp extension is created if not already
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
